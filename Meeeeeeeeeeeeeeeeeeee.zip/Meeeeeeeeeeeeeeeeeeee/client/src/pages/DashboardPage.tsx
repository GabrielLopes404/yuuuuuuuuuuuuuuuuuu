import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, Users, FileText, DollarSign, Activity, ChevronLeft, ChevronRight, ArrowUpRight, ArrowDownRight, CreditCard, Wallet, Receipt, Clock, CheckCircle2, XCircle, AlertCircle } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import AppLayout from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  Legend,
  RadialBarChart,
  RadialBar,
} from "recharts";

interface Metrics {
  totalCustomers: number;
  totalInvoices: number;
  totalRevenue: string;
  paidInvoices: number;
  pendingInvoices: number;
  overdueInvoices: number;
}

interface Activity {
  id: string;
  action: string;
  entityType: string;
  details: string;
  createdAt: string;
}

const CHART_COLORS = {
  violet: "#8b5cf6",
  cyan: "#06b6d4",
  pink: "#ec4899",
  green: "#10b981",
  orange: "#f59e0b",
  red: "#ef4444",
};

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { type: "spring", stiffness: 100 }
  }
};

export default function DashboardPage() {
  const { data: metrics } = useQuery<Metrics>({
    queryKey: ["/api/metrics"],
    queryFn: async () => {
      const res = await fetch("/api/metrics", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch metrics");
      return res.json();
    },
  });

  const { data: activities } = useQuery<Activity[]>({
    queryKey: ["/api/activities"],
    queryFn: async () => {
      const res = await fetch("/api/activities?limit=10", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch activities");
      return res.json();
    },
  });

  const { data: monthlyRevenueData } = useQuery<Array<{month: string; monthIndex: number; receita: number}>>({
    queryKey: ["/api/metrics/monthly-revenue"],
    queryFn: async () => {
      const res = await fetch("/api/metrics/monthly-revenue", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch monthly revenue");
      return res.json();
    },
  });

  const invoiceStats = [
    { name: "Pagas", value: metrics?.paidInvoices || 0, color: CHART_COLORS.green, icon: CheckCircle2 },
    { name: "Pendentes", value: metrics?.pendingInvoices || 0, color: CHART_COLORS.orange, icon: Clock },
    { name: "Vencidas", value: metrics?.overdueInvoices || 0, color: CHART_COLORS.red, icon: AlertCircle },
  ];

  const revenueData = monthlyRevenueData 
    ? monthlyRevenueData.map(item => ({
        name: item.month,
        receita: Math.round(item.receita),
        despesas: Math.round(item.receita * 0.6) // Estimando 60% de despesas
      }))
    : [
        { name: "Jan", receita: 0, despesas: 0 },
        { name: "Fev", receita: 0, despesas: 0 },
        { name: "Mar", receita: 0, despesas: 0 },
        { name: "Abr", receita: 0, despesas: 0 },
        { name: "Mai", receita: 0, despesas: 0 },
        { name: "Jun", receita: 0, despesas: 0 },
      ];

  const comparisonData = [
    { 
      name: "Recebimentos", 
      value: metrics?.paidInvoices || 0, 
      fill: CHART_COLORS.green,
      percentage: 100
    },
    { 
      name: "Pendentes", 
      value: metrics?.pendingInvoices || 0, 
      fill: CHART_COLORS.orange,
      percentage: 75
    },
    { 
      name: "Vencidas", 
      value: metrics?.overdueInvoices || 0, 
      fill: CHART_COLORS.red,
      percentage: 50
    },
  ];

  const mrr = metrics?.totalRevenue ? (Number(metrics.totalRevenue) / 6).toFixed(2) : "0.00";
  const previousMrr = "1250.00";
  const growth = ((Number(mrr) - Number(previousMrr)) / Number(previousMrr) * 100).toFixed(1);
  const isPositiveGrowth = Number(growth) >= 0;

  const formatActionText = (action: string) => {
    const actionMap: Record<string, string> = {
      user_registered: "Novo usuário registrado",
      customer_created: "Cliente criado",
      customer_updated: "Cliente atualizado",
      customer_deleted: "Cliente deletado",
      invoice_created: "Fatura criada",
      invoice_updated: "Fatura atualizada",
      invoice_deleted: "Fatura deletada",
    };
    return actionMap[action] || action;
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = Math.floor((now.getTime() - date.getTime()) / 1000);

    if (diff < 60) return "Agora";
    if (diff < 3600) return `${Math.floor(diff / 60)}m atrás`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h atrás`;
    return `${Math.floor(diff / 86400)}d atrás`;
  };

  const [currentMonth, setCurrentMonth] = useState(new Date());
  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();
    
    return { daysInMonth, startingDayOfWeek };
  };

  const { daysInMonth, startingDayOfWeek } = getDaysInMonth(currentMonth);
  const monthNames = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", 
                      "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background/95 backdrop-blur-sm border border-border rounded-lg p-3 shadow-xl">
          <p className="font-semibold text-sm mb-2">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-sm flex items-center gap-2">
              <span className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }} />
              <span className="text-muted-foreground">{entry.name}:</span>
              <span className="font-bold">
                R$ {entry.value.toLocaleString("pt-BR")}
              </span>
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <AppLayout>
      <motion.div 
        className="space-y-6"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Header Section */}
        <motion.div variants={itemVariants} className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-3">
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight bg-gradient-to-r from-violet-600 via-purple-600 to-cyan-600 bg-clip-text text-transparent">
                Boa noite, Gabriel
              </h1>
              <span className="px-3 py-1 bg-gradient-to-r from-pink-500 to-rose-500 text-white text-xs sm:text-sm font-bold rounded-full shadow-lg">
                Pessoal
              </span>
            </div>
            <p className="text-sm sm:text-base text-muted-foreground mt-1">
              Visão geral das suas métricas e atividades
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="shadow-sm">
              <Receipt className="h-4 w-4 mr-2" />
              <span className="hidden sm:inline">Exportar</span>
            </Button>
          </div>
        </motion.div>

        {/* Metrics Cards */}
        <motion.div variants={itemVariants} className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
          {/* Total Revenue Card */}
          <motion.div whileHover={{ y: -4 }} transition={{ type: "spring", stiffness: 300 }}>
            <Card className="relative overflow-hidden border-violet-500/20 hover:border-violet-500/40 transition-all duration-300 shadow-lg hover:shadow-xl bg-gradient-to-br from-violet-500/5 to-transparent">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-violet-500/10 to-transparent rounded-full blur-2xl" />
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Receita Total</CardTitle>
                <div className="h-10 w-10 rounded-full bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center shadow-lg">
                  <DollarSign className="h-5 w-5 text-white" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent">
                  R$ {Number(metrics?.totalRevenue || 0).toLocaleString("pt-BR", {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2,
                  })}
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-xs text-muted-foreground">
                    MRR: R$ {Number(mrr).toLocaleString("pt-BR")}
                  </span>
                  <div className={`flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full ${
                    isPositiveGrowth ? "bg-green-500/10 text-green-600" : "bg-red-500/10 text-red-600"
                  }`}>
                    {isPositiveGrowth ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
                    {Math.abs(Number(growth))}%
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Customers Card */}
          <motion.div whileHover={{ y: -4 }} transition={{ type: "spring", stiffness: 300 }}>
            <Card className="relative overflow-hidden border-cyan-500/20 hover:border-cyan-500/40 transition-all duration-300 shadow-lg hover:shadow-xl bg-gradient-to-br from-cyan-500/5 to-transparent">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-cyan-500/10 to-transparent rounded-full blur-2xl" />
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Clientes Ativos</CardTitle>
                <div className="h-10 w-10 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg">
                  <Users className="h-5 w-5 text-white" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">
                  {metrics?.totalCustomers || 0}
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  <span className="text-green-600 font-semibold">+12.5%</span> vs mês anterior
                </p>
              </CardContent>
            </Card>
          </motion.div>

          {/* Invoices Card */}
          <motion.div whileHover={{ y: -4 }} transition={{ type: "spring", stiffness: 300 }}>
            <Card className="relative overflow-hidden border-pink-500/20 hover:border-pink-500/40 transition-all duration-300 shadow-lg hover:shadow-xl bg-gradient-to-br from-pink-500/5 to-transparent">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-pink-500/10 to-transparent rounded-full blur-2xl" />
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Faturas</CardTitle>
                <div className="h-10 w-10 rounded-full bg-gradient-to-br from-pink-500 to-rose-600 flex items-center justify-center shadow-lg">
                  <FileText className="h-5 w-5 text-white" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent">
                  {metrics?.totalInvoices || 0}
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  {metrics?.paidInvoices || 0} pagas · {metrics?.pendingInvoices || 0} pendentes
                </p>
              </CardContent>
            </Card>
          </motion.div>

          {/* Conversion Rate Card */}
          <motion.div whileHover={{ y: -4 }} transition={{ type: "spring", stiffness: 300 }}>
            <Card className="relative overflow-hidden border-green-500/20 hover:border-green-500/40 transition-all duration-300 shadow-lg hover:shadow-xl bg-gradient-to-br from-green-500/5 to-transparent">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-green-500/10 to-transparent rounded-full blur-2xl" />
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Taxa de Conversão</CardTitle>
                <div className="h-10 w-10 rounded-full bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center shadow-lg">
                  <TrendingUp className="h-5 w-5 text-white" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                  {metrics?.totalInvoices && metrics.paidInvoices
                    ? ((metrics.paidInvoices / metrics.totalInvoices) * 100).toFixed(1)
                    : "0"}%
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  Faturas pagas com sucesso
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>

        {/* Charts Section */}
        <motion.div variants={itemVariants} className="grid gap-6 grid-cols-1 lg:grid-cols-3">
          {/* Revenue Chart */}
          <Card className="lg:col-span-2 shadow-xl border-border/50 hover:border-border transition-all duration-300">
            <CardHeader>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <CardTitle className="text-lg sm:text-xl font-bold flex items-center gap-2">
                    <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
                      <TrendingUp className="h-4 w-4 text-white" />
                    </div>
                    Fluxo de Caixa
                  </CardTitle>
                  <p className="text-xs sm:text-sm text-muted-foreground mt-1">
                    Receitas vs Despesas - Últimos 6 meses
                  </p>
                </div>
                <div className="flex gap-4 text-xs sm:text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-violet-500" />
                    <span>Receitas</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-pink-500" />
                    <span>Despesas</span>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={revenueData}>
                  <defs>
                    <linearGradient id="colorReceita" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={CHART_COLORS.violet} stopOpacity={0.3}/>
                      <stop offset="95%" stopColor={CHART_COLORS.violet} stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorDespesas" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={CHART_COLORS.pink} stopOpacity={0.3}/>
                      <stop offset="95%" stopColor={CHART_COLORS.pink} stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.1} />
                  <XAxis 
                    dataKey="name" 
                    tick={{ fill: '#9ca3af', fontSize: 12 }}
                    tickLine={{ stroke: '#374151' }}
                  />
                  <YAxis 
                    tick={{ fill: '#9ca3af', fontSize: 12 }}
                    tickLine={{ stroke: '#374151' }}
                    tickFormatter={(value) => `R$${value}`}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Area
                    type="monotone"
                    dataKey="receita"
                    stroke={CHART_COLORS.violet}
                    strokeWidth={3}
                    fill="url(#colorReceita)"
                    name="Receita"
                  />
                  <Area
                    type="monotone"
                    dataKey="despesas"
                    stroke={CHART_COLORS.pink}
                    strokeWidth={3}
                    fill="url(#colorDespesas)"
                    name="Despesas"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Status das Faturas - Pie Chart + Stats */}
          <Card className="shadow-xl border-border/50 hover:border-border transition-all duration-300">
            <CardHeader>
              <CardTitle className="text-lg sm:text-xl font-bold flex items-center gap-2">
                <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                  <FileText className="h-4 w-4 text-white" />
                </div>
                Status das Faturas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie
                    data={invoiceStats}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {invoiceStats.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={entry.color}
                        stroke={entry.color}
                        strokeWidth={2}
                      />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                </PieChart>
              </ResponsiveContainer>
              
              {/* Stats List */}
              <div className="space-y-3 mt-4">
                {invoiceStats.map((stat, index) => {
                  const Icon = stat.icon;
                  return (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="flex items-center justify-between p-3 rounded-lg border border-border/50 hover:border-border transition-all bg-card/50 backdrop-blur-sm"
                    >
                      <div className="flex items-center gap-3">
                        <div 
                          className="h-10 w-10 rounded-lg flex items-center justify-center"
                          style={{ backgroundColor: `${stat.color}20` }}
                        >
                          <Icon className="h-5 w-5" style={{ color: stat.color }} />
                        </div>
                        <span className="font-medium text-sm">{stat.name}</span>
                      </div>
                      <div className="text-right">
                        <div className="text-xl font-bold" style={{ color: stat.color }}>
                          {stat.value}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {((stat.value / (metrics?.totalInvoices || 1)) * 100).toFixed(0)}%
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Comparison Chart & Calendar */}
        <motion.div variants={itemVariants} className="grid gap-6 grid-cols-1 lg:grid-cols-3">
          {/* Radial Comparison Chart */}
          <Card className="lg:col-span-2 shadow-xl border-border/50 hover:border-border transition-all duration-300">
            <CardHeader>
              <CardTitle className="text-lg sm:text-xl font-bold flex items-center gap-2">
                <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-pink-500 to-rose-600 flex items-center justify-center">
                  <Wallet className="h-4 w-4 text-white" />
                </div>
                Comparativo de Faturas
              </CardTitle>
              <p className="text-xs sm:text-sm text-muted-foreground">
                Distribuição por status em tempo real
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <ResponsiveContainer width="100%" height={280}>
                  <RadialBarChart 
                    cx="50%" 
                    cy="50%" 
                    innerRadius="10%" 
                    outerRadius="90%" 
                    data={comparisonData}
                    startAngle={90}
                    endAngle={-270}
                  >
                    <RadialBar
                      background
                      dataKey="value"
                      cornerRadius={10}
                    />
                    <Legend 
                      iconSize={10} 
                      layout="vertical" 
                      verticalAlign="middle" 
                      align="right"
                      wrapperStyle={{ fontSize: '12px' }}
                    />
                    <Tooltip content={<CustomTooltip />} />
                  </RadialBarChart>
                </ResponsiveContainer>
                
                {/* Additional Stats */}
                <div className="flex flex-col justify-center space-y-4">
                  <div className="p-4 rounded-xl bg-gradient-to-br from-green-500/10 to-emerald-500/5 border border-green-500/20">
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                      <span className="text-sm font-medium text-green-600">Recebido</span>
                    </div>
                    <div className="text-2xl font-bold text-green-600">
                      R$ {(Number(metrics?.totalRevenue || 0) * 0.65).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {metrics?.paidInvoices || 0} faturas quitadas
                    </div>
                  </div>
                  
                  <div className="p-4 rounded-xl bg-gradient-to-br from-orange-500/10 to-amber-500/5 border border-orange-500/20">
                    <div className="flex items-center gap-2 mb-2">
                      <Clock className="h-5 w-5 text-orange-500" />
                      <span className="text-sm font-medium text-orange-600">A Receber</span>
                    </div>
                    <div className="text-2xl font-bold text-orange-600">
                      R$ {(Number(metrics?.totalRevenue || 0) * 0.25).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {metrics?.pendingInvoices || 0} faturas pendentes
                    </div>
                  </div>
                  
                  <div className="p-4 rounded-xl bg-gradient-to-br from-red-500/10 to-rose-500/5 border border-red-500/20">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertCircle className="h-5 w-5 text-red-500" />
                      <span className="text-sm font-medium text-red-600">Atrasado</span>
                    </div>
                    <div className="text-2xl font-bold text-red-600">
                      R$ {(Number(metrics?.totalRevenue || 0) * 0.10).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {metrics?.overdueInvoices || 0} faturas vencidas
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Calendar */}
          <Card className="shadow-xl border-border/50 hover:border-border transition-all duration-300">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base sm:text-lg font-bold">
                  {monthNames[currentMonth.getMonth()]}
                </CardTitle>
                <div className="flex gap-1">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 hover:bg-violet-500/10 hover:text-violet-600"
                    onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1))}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 hover:bg-violet-500/10 hover:text-violet-600"
                    onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1))}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <p className="text-xs text-muted-foreground">{currentMonth.getFullYear()}</p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-1 text-center mb-2">
                {["D", "S", "T", "Q", "Q", "S", "S"].map((day, i) => (
                  <div key={i} className="text-xs font-bold text-muted-foreground p-1">
                    {day}
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-7 gap-1">
                {Array.from({ length: startingDayOfWeek }).map((_, index) => (
                  <div key={`empty-${index}`} className="aspect-square" />
                ))}
                {Array.from({ length: daysInMonth }).map((_, index) => {
                  const day = index + 1;
                  const isToday = day === new Date().getDate() && 
                                 currentMonth.getMonth() === new Date().getMonth() &&
                                 currentMonth.getFullYear() === new Date().getFullYear();
                  return (
                    <motion.button
                      key={day}
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.95 }}
                      className={`aspect-square flex items-center justify-center text-xs sm:text-sm rounded-lg transition-all font-medium
                        ${isToday 
                          ? "bg-gradient-to-br from-violet-500 to-purple-600 text-white shadow-lg font-bold" 
                          : "hover:bg-violet-500/10 hover:text-violet-600"}
                      `}
                    >
                      {day}
                    </motion.button>
                  );
                })}
              </div>
              
              <div className="mt-6 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-sm">Hoje</h4>
                  <span className="text-xs px-2 py-1 rounded-full bg-violet-500/10 text-violet-600 font-semibold">
                    {new Date().getDate()} {monthNames[new Date().getMonth()].slice(0, 3)}
                  </span>
                </div>
                <div className="text-center py-8 text-sm text-muted-foreground bg-muted/30 rounded-lg">
                  <Clock className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  Nenhum compromisso hoje
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Activities */}
        <motion.div variants={itemVariants}>
          <Card className="shadow-xl border-border/50 hover:border-border transition-all duration-300">
            <CardHeader>
              <CardTitle className="text-lg sm:text-xl font-bold flex items-center gap-2">
                <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center">
                  <Activity className="h-4 w-4 text-white" />
                </div>
                Atividades Recentes
              </CardTitle>
              <p className="text-xs sm:text-sm text-muted-foreground">
                Últimas atualizações do sistema
              </p>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {activities && activities.length > 0 ? (
                  activities.map((activity, index) => (
                    <motion.div
                      key={activity.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="flex items-start gap-4 p-3 sm:p-4 border border-border/50 rounded-lg hover:border-border transition-all hover:shadow-md bg-card/50 backdrop-blur-sm"
                    >
                      <div className="h-10 w-10 rounded-full bg-gradient-to-br from-violet-500/20 to-purple-500/20 flex items-center justify-center flex-shrink-0 border border-violet-500/20">
                        <Activity className="h-5 w-5 text-violet-500" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-foreground truncate">
                          {formatActionText(activity.action)}
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {formatTimestamp(activity.createdAt)}
                        </p>
                      </div>
                    </motion.div>
                  ))
                ) : (
                  <div className="text-center py-12 text-sm text-muted-foreground bg-muted/30 rounded-lg">
                    <Activity className="h-12 w-12 mx-auto mb-3 opacity-30" />
                    <p>Nenhuma atividade recente</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </AppLayout>
  );
}
