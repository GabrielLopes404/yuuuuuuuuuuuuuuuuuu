import SubscriptionPage from "./SubscriptionPage";

export default function PricingPage() {
  return <SubscriptionPage />;
}
